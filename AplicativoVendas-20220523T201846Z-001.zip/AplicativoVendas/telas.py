from kivy.uix.screenmanager import Screen


class HomePage(Screen):
    pass


class AjustesPage(Screen):
    pass


class AdicionarVendasPage(Screen):
    pass


class ListarVendedoresPage(Screen):
    pass


class FotoPerfilPage(Screen):
    pass


class AdicionarVendedorPage(Screen):
    pass


class TodasVendasPage(Screen):
    pass


class LoginPage(Screen):
    pass


class VendasOutroVendedorPage(Screen):
    pass
